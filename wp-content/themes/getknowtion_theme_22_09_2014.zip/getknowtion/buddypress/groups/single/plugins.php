<?php do_action( 'bp_before_group_plugin_template' ); ?>

<?php do_action( 'bp_template_content' ); ?>

<?php do_action( 'bp_after_group_plugin_template' );
