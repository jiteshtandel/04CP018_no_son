<?php

/**
 * BuddyPress - Users Header
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */
?>
<?php do_action( 'bp_before_member_header' ); ?>
<?php do_action( 'bp_after_member_header' ); ?>
<?php do_action( 'template_notices' ); ?>